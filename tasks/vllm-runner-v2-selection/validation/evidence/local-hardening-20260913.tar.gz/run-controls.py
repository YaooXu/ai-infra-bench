from pathlib import Path
import concurrent.futures,json,subprocess,time,hashlib
root=Path('/tmp/pr56-hardening-20260913');task=Path('/tmp/ai-infra-pr56-hardening/tasks/vllm-runner-v2-selection')
image='pr56-hardening:base'
cases=[{'name':'oracle','expected_reward':1,'patch':'solution/oracle.patch'},{'name':'base','expected_reward':0,'patch':None}]
cases += [{**c,'patch':'validation/'+c['patch']} for c in json.loads((task/'validation/ci-cases.json').read_text())['cases']]
(root/'tested-hashes.json').write_text(json.dumps({str(p.relative_to(task)):hashlib.sha256(p.read_bytes()).hexdigest() for p in task.rglob('*') if p.is_file() and ('tests' in p.parts or 'solution' in p.parts or p.name=='instruction.md' or p.suffix=='.patch')},indent=2))
def run(c):
 name='pr56-harden-'+c['name'];out=root/'runs'/c['name'];out.mkdir(parents=True,exist_ok=True)
 cmd=['docker','run','-d','--name',name,'--network','none','--gpus','device=3','--cpus','4','--memory','16g','--user','root','--entrypoint','sleep','-v',str(task/'tests')+':/tests:ro','-v',str(task/'solution')+':/solution:ro','-v',str(task/'validation')+':/validation:ro',image,'infinity']
 start=time.monotonic();subprocess.run(cmd,check=True,stdout=subprocess.DEVNULL)
 try:
  if c['patch']:subprocess.run(['docker','exec','-u','agent','-w','/workspace/repo',name,'git','apply','/'+c['patch']],check=True,stdout=subprocess.DEVNULL)
  with (out/'verifier.log').open('w') as f:
   p=subprocess.run(['docker','exec',name,'bash','/tests/test.sh'],stdout=f,stderr=subprocess.STDOUT,timeout=550)
  reward=subprocess.run(['docker','exec',name,'cat','/logs/verifier/reward.txt'],text=True,capture_output=True)
  subprocess.run(['docker','cp',name+':/logs/verifier/worker.log',str(out/'worker.log')],capture_output=True)
  r={'name':c['name'],'expected_reward':c['expected_reward'],'reward':reward.stdout.strip(),'exit_code':p.returncode,'seconds':round(time.monotonic()-start,2),'container':name}
  (out/'result.json').write_text(json.dumps(r,indent=2));print(json.dumps(r),flush=True);return r
 finally:subprocess.run(['docker','stop','-t','2',name],capture_output=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:results=list(pool.map(run,cases))
(root/'matrix.json').write_text(json.dumps(results,indent=2))
assert all(r['reward']==str(r['expected_reward']) and r['exit_code']==0 for r in results),results
