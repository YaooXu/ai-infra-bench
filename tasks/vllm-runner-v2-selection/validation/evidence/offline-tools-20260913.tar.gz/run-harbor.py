import asyncio,json,hashlib,shutil
from pathlib import Path
from harbor.models.trial.config import TrialConfig
from harbor.trial.trial import Trial
root=Path(__file__).parent
source=Path('/tmp/ai-infra-pr56-hardening/tasks/vllm-runner-v2-selection')
async def main():
 results=[]
 for label,patch,expected in [('oracle','solution/oracle.patch',1),('os-exit','validation/os-exit-zero-bypass.patch',0),('system-exit','validation/system-exit-zero-bypass.patch',0)]:
  task=root/'harbor-tasks'/label;shutil.copytree(source,task)
  if label!='oracle':shutil.copyfile(source/patch,task/'solution/oracle.patch')
  hashes={str(p.relative_to(task)):hashlib.sha256(p.read_bytes()).hexdigest() for p in task.rglob('*') if p.is_file()}
  (root/f'harbor-{label}-inputs.json').write_text(json.dumps(hashes,indent=2)+'\n')
  trial=await Trial.create(TrialConfig.model_validate({'task':{'path':str(task)},'trial_name':f'pr56-tools-{label}','trials_dir':str(root/'trials'),'agent':{'name':'oracle'},'environment':{'import_path':'harbor_gpu:NvidiaDockerEnvironment','kwargs':{'gpu_device':'3'}}}))
  r=await trial.run();(root/f'harbor-{label}-result.json').write_text(r.model_dump_json(indent=2))
  for f,h in hashes.items():assert hashlib.sha256((task/f).read_bytes()).hexdigest()==h,f
  assert r.exception_info is None, r.exception_info
  assert r.verifier_result.rewards['reward']==expected,r.verifier_result
  item={'case':label,'expected':expected,'reward':r.verifier_result.rewards['reward'],'exception':None,'checksum':r.task_checksum};results.append(item);print(item,flush=True)
 (root/'harbor-results.json').write_text(json.dumps(results,indent=2)+'\n')
asyncio.run(main())
