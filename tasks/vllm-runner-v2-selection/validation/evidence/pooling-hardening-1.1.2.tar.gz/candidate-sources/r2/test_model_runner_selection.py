# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM project

from types import SimpleNamespace
from unittest.mock import Mock

import pytest

from vllm import envs
from vllm.config import VllmConfig
from vllm.platforms import current_platform


@pytest.fixture
def config(monkeypatch):
    # Exercise selection without downloading model weights/configs or requiring
    # a GPU. These are the resolved configuration values seen at selection time.
    monkeypatch.delenv("VLLM_USE_V2_MODEL_RUNNER", raising=False)
    monkeypatch.setattr(current_platform, "is_cuda_alike", lambda: True)
    config = object.__new__(VllmConfig)
    config.model_config = SimpleNamespace(
        architecture="Qwen3ForCausalLM",
        runner_type="generate",
        convert_type="none",
        is_multimodal_model=False,
        is_moe=False,
        quantization=None,
        has_inner_state=False,
        enable_prompt_embeds=False,
        enable_return_routed_experts=False,
        logits_processors=None,
        logprobs_mode="raw_logprobs",
        attn_type="decoder",
        pooler_config=SimpleNamespace(
            task="embed",
            seq_pooling_type="LAST",
            use_activation=True,
            dimensions=None,
        ),
    )
    config.parallel_config = SimpleNamespace(
        prefill_context_parallel_size=1,
        pipeline_parallel_size=1,
        enable_dbo=False,
    )
    config.compilation_config = SimpleNamespace(
        pass_config=SimpleNamespace(enable_sp=False)
    )
    config.cache_config = SimpleNamespace(
        kv_sharing_fast_prefill=False, mamba_cache_mode="none"
    )
    config.quant_config = None
    config.speculative_config = None
    config.ec_transfer_config = None
    return config


@pytest.mark.parametrize(
    "override, expected", [(None, None), ("0", False), ("1", True)]
)
def test_runner_environment(monkeypatch, override, expected):
    monkeypatch.delenv("VLLM_USE_V2_MODEL_RUNNER", raising=False)
    if override is not None:
        monkeypatch.setenv("VLLM_USE_V2_MODEL_RUNNER", override)
    assert envs.VLLM_USE_V2_MODEL_RUNNER is expected


@pytest.mark.parametrize("override", [None, "0", "1"])
@pytest.mark.parametrize(
    "model_changes, in_rollout",
    [
        ({}, True),
        ({"architecture": "LlamaForCausalLM"}, False),
        ({"architecture": "Qwen3MoeForCausalLM", "is_moe": True}, False),
        ({"is_moe": True}, False),
        ({"quantization": "fp8"}, False),
        ({"runner_type": "pooling"}, False),
        ({"is_multimodal_model": True}, False),
    ],
)
def test_rollout_and_overrides(
    config, monkeypatch, override, model_changes, in_rollout
):
    for name, value in model_changes.items():
        setattr(config.model_config, name, value)
    if override is not None:
        monkeypatch.setenv("VLLM_USE_V2_MODEL_RUNNER", override)
    config._set_model_runner()
    assert config.use_v2_model_runner is (
        override == "1" or (override is None and in_rollout)
    )


@pytest.mark.parametrize("override", [None, "0", "1"])
@pytest.mark.parametrize(
    "section, name, value, error",
    [
        ("model_config", "has_inner_state", True, "hybrid/mamba"),
        ("model_config", "enable_prompt_embeds", True, "prompt embeddings"),
        ("model_config", "enable_return_routed_experts", True, "routed experts"),
        ("model_config", "logits_processors", ["custom"], "custom logits"),
        ("model_config", "logprobs_mode", "raw_logits", "logprobs mode"),
        ("model_config", "logprobs_mode", "processed_logits", "logprobs mode"),
        ("parallel_config", "prefill_context_parallel_size", 2, "prefill context"),
        ("parallel_config", "enable_dbo", True, "dual batch overlap"),
        ("cache_config", "kv_sharing_fast_prefill", True, "KV sharing"),
        ("cache_config", "mamba_cache_mode", "align", "mamba cache align"),
        (None, "ec_transfer_config", SimpleNamespace(), "EC transfer"),
        (
            None,
            "speculative_config",
            SimpleNamespace(method="ngram"),
            "speculative method 'ngram'",
        ),
        (
            "compilation_config",
            "pass_config",
            SimpleNamespace(enable_sp=True),
            "sequence parallelism",
        ),
    ],
)
def test_unsupported_features(
    config, monkeypatch, override, section, name, value, error
):
    setattr(getattr(config, section) if section else config, name, value)
    if override is not None:
        monkeypatch.setenv("VLLM_USE_V2_MODEL_RUNNER", override)
    if override == "1":
        with pytest.raises(ValueError, match=f"VLLM_USE_V2_MODEL_RUNNER=1.*{error}"):
            config._set_model_runner()
    else:
        config._set_model_runner()
        assert config.use_v2_model_runner is False


@pytest.mark.parametrize("method", ["eagle", "eagle3", "mtp"])
@pytest.mark.parametrize("pp_size", [1, 2])
def test_supported_speculation(config, monkeypatch, method, pp_size):
    config.speculative_config = SimpleNamespace(method=method)
    config.parallel_config.pipeline_parallel_size = pp_size
    unsupported = method == "eagle3" and pp_size > 1
    config._set_model_runner()
    assert config.use_v2_model_runner is not unsupported
    monkeypatch.setenv("VLLM_USE_V2_MODEL_RUNNER", "1")
    if unsupported:
        with pytest.raises(ValueError, match="EAGLE3 with pipeline parallelism"):
            config._set_model_runner()
    else:
        config._set_model_runner()
        assert config.use_v2_model_runner


def test_unsupported_platform(config, monkeypatch):
    monkeypatch.setattr(current_platform, "is_cuda_alike", lambda: False)
    config._set_model_runner()
    assert not config.use_v2_model_runner
    monkeypatch.setenv("VLLM_USE_V2_MODEL_RUNNER", "1")
    with pytest.raises(ValueError, match="platforms"):
        config._set_model_runner()


def test_missing_model(config):
    config.model_config = None
    config._set_model_runner()
    assert not config.use_v2_model_runner


def test_resolved_quantization(config):
    config.quant_config = Mock()
    config._set_model_runner()
    assert not config.use_v2_model_runner


@pytest.mark.parametrize(
    "name, value",
    [
        ("task", "classify"),
        ("seq_pooling_type", "MEAN"),
        ("use_activation", False),
        ("dimensions", 128),
    ],
)
def test_unsupported_pooling(config, monkeypatch, name, value):
    config.model_config.runner_type = "pooling"
    setattr(config.model_config.pooler_config, name, value)
    config._set_model_runner()
    assert not config.use_v2_model_runner
    monkeypatch.setenv("VLLM_USE_V2_MODEL_RUNNER", "1")
    with pytest.raises(ValueError, match="pooling other than"):
        config._set_model_runner()


def test_default_embedding_task(config, monkeypatch):
    config.model_config.runner_type = "pooling"
    config.model_config.convert_type = "embed"
    config.model_config.pooler_config.task = None
    monkeypatch.setenv("VLLM_USE_V2_MODEL_RUNNER", "1")
    config._set_model_runner()
    assert config.use_v2_model_runner


@pytest.mark.parametrize("selected", [False, True])
def test_worker_uses_resolved_runner(config, monkeypatch, selected):
    from vllm.distributed.elastic_ep import elastic_execute
    from vllm.v1.worker.gpu_worker import Worker, WorkerBase

    if not selected:
        monkeypatch.setenv("VLLM_USE_V2_MODEL_RUNNER", "0")
    config._set_model_runner()

    # Simulate a worker process with a conflicting environment. The engine's
    # resolved choice must survive the process boundary.
    monkeypatch.setenv("VLLM_USE_V2_MODEL_RUNNER", "0" if selected else "1")
    config.weight_transfer_config = None
    config.profiler_config = SimpleNamespace(profiler=None)

    def init_base(self, vllm_config, **kwargs):
        self.vllm_config = vllm_config

    monkeypatch.setattr(WorkerBase, "__init__", init_base)
    monkeypatch.setattr(elastic_execute, "ElasticEPScalingExecutor", Mock())
    worker = Worker(config, local_rank=0, rank=0, distributed_init_method="")
    assert worker.use_v2_model_runner is selected
