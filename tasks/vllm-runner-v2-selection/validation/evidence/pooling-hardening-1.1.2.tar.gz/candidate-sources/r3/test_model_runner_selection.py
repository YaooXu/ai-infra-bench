# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM project

from types import SimpleNamespace
from unittest.mock import Mock, patch

import pytest

from vllm import envs
from vllm.config import VllmConfig


@pytest.fixture
def config(monkeypatch):
    monkeypatch.delenv("VLLM_USE_V2_MODEL_RUNNER", raising=False)
    # Test selection without loading a model or initializing a device.
    config = object.__new__(VllmConfig)
    config.model_config = SimpleNamespace(
        architecture="Qwen3ForCausalLM",
        runner_type="generate",
        is_moe=False,
        is_multimodal_model=False,
        quantization=None,
        has_inner_state=False,
        enable_prompt_embeds=False,
        logprobs_mode="raw_logprobs",
        enable_return_routed_experts=False,
        logits_processors=None,
    )
    config.parallel_config = SimpleNamespace(
        prefill_context_parallel_size=1,
        pipeline_parallel_size=1,
        enable_dbo=False,
        enable_elastic_ep=False,
        enable_eplb=False,
    )
    config.compilation_config = SimpleNamespace(
        pass_config=SimpleNamespace(enable_sp=False)
    )
    config.cache_config = SimpleNamespace(
        kv_sharing_fast_prefill=False, mamba_cache_mode="none"
    )
    config.speculative_config = None
    config.ec_transfer_config = None
    config.quant_config = None
    with patch("vllm.platforms.current_platform") as platform:
        platform.is_cuda_alike.return_value = True
        platform.is_xpu.return_value = False
        yield config


@pytest.mark.parametrize(
    "override, expected", [(None, True), ("0", False), ("1", True)]
)
def test_qwen3_selection(config, monkeypatch, override, expected):
    if override is not None:
        monkeypatch.setenv("VLLM_USE_V2_MODEL_RUNNER", override)
    config._set_model_runner()
    assert config.use_v2_model_runner is expected


@pytest.mark.parametrize(
    "field, value",
    [
        ("architecture", "LlamaForCausalLM"),
        ("architecture", "Qwen3MoeForCausalLM"),
        ("architecture", "Qwen3NextForCausalLM"),
        ("runner_type", "pooling"),
        ("is_moe", True),
        ("is_multimodal_model", True),
        ("quantization", "fp8"),
    ],
)
def test_rollout_is_narrower_than_support(config, monkeypatch, field, value):
    setattr(config.model_config, field, value)
    config._set_model_runner()
    assert not config.use_v2_model_runner
    monkeypatch.setenv("VLLM_USE_V2_MODEL_RUNNER", "1")
    config._set_model_runner()
    assert config.use_v2_model_runner


@pytest.mark.parametrize(
    "section, field, value, reason",
    [
        ("model_config", "has_inner_state", True, "hybrid/mamba"),
        ("model_config", "enable_prompt_embeds", True, "prompt embeddings"),
        ("model_config", "logprobs_mode", "raw_logits", "logprobs mode"),
        ("model_config", "logprobs_mode", "processed_logits", "logprobs mode"),
        ("model_config", "enable_return_routed_experts", True, "routed experts"),
        ("model_config", "logits_processors", ["custom"], "logits processors"),
        ("parallel_config", "prefill_context_parallel_size", 2, "prefill context"),
        ("parallel_config", "enable_dbo", True, "dual batch overlap"),
        ("cache_config", "kv_sharing_fast_prefill", True, "KV sharing"),
        ("cache_config", "mamba_cache_mode", "align", "mamba_cache_mode"),
        ("compilation_config.pass_config", "enable_sp", True, "sequence parallelism"),
        (None, "ec_transfer_config", object(), "EC transfer"),
        (
            None,
            "speculative_config",
            SimpleNamespace(method="ngram"),
            "speculative method",
        ),
    ],
)
def test_unsupported_features(config, monkeypatch, section, field, value, reason):
    target = config
    for name in section.split(".") if section else []:
        target = getattr(target, name)
    setattr(target, field, value)
    config._set_model_runner()
    assert not config.use_v2_model_runner
    monkeypatch.setenv("VLLM_USE_V2_MODEL_RUNNER", "1")
    with pytest.raises(ValueError, match=f"VLLM_USE_V2_MODEL_RUNNER=1.*{reason}"):
        config._set_model_runner()
    monkeypatch.setenv("VLLM_USE_V2_MODEL_RUNNER", "0")
    config._set_model_runner()
    assert not config.use_v2_model_runner


@pytest.mark.parametrize("method", ["eagle", "eagle3", "mtp"])
def test_supported_speculation(config, method):
    config.speculative_config = SimpleNamespace(method=method)
    config._set_model_runner()
    assert config.use_v2_model_runner


def test_eagle3_pipeline_parallelism(config, monkeypatch):
    config.speculative_config = SimpleNamespace(method="eagle3")
    config.parallel_config.pipeline_parallel_size = 2
    config._set_model_runner()
    assert not config.use_v2_model_runner
    monkeypatch.setenv("VLLM_USE_V2_MODEL_RUNNER", "1")
    with pytest.raises(ValueError, match="EAGLE3 with pipeline parallelism"):
        config._set_model_runner()


def test_unsupported_platform(config, monkeypatch):
    with patch("vllm.platforms.current_platform") as platform:
        platform.is_cuda_alike.return_value = False
        platform.is_xpu.return_value = False
        config._set_model_runner()
        assert not config.use_v2_model_runner
        monkeypatch.setenv("VLLM_USE_V2_MODEL_RUNNER", "1")
        with pytest.raises(ValueError, match="this platform"):
            config._set_model_runner()


def test_no_model(config):
    config.model_config = None
    config._set_model_runner()
    assert not config.use_v2_model_runner


@pytest.mark.parametrize("value, expected", [(None, None), ("0", False), ("1", True)])
def test_environment_override(monkeypatch, value, expected):
    monkeypatch.delenv("VLLM_USE_V2_MODEL_RUNNER", raising=False)
    if value is not None:
        monkeypatch.setenv("VLLM_USE_V2_MODEL_RUNNER", value)
    assert envs.environment_variables["VLLM_USE_V2_MODEL_RUNNER"]() is expected


@pytest.mark.parametrize("selected", [False, True])
def test_worker_uses_resolved_selection(monkeypatch, selected):
    from vllm.v1.worker.gpu_worker import Worker

    # A worker's environment must not override the engine's resolved choice.
    monkeypatch.setenv("VLLM_USE_V2_MODEL_RUNNER", "0" if selected else "1")
    config = Mock(
        use_v2_model_runner=selected,
        weight_transfer_config=None,
        profiler_config=SimpleNamespace(profiler=None),
    )
    with patch("vllm.distributed.elastic_ep.elastic_execute.ElasticEPScalingExecutor"):
        worker = Worker(config, 0, 0, "tcp://localhost:12345")
    assert worker.use_v2_model_runner is selected
