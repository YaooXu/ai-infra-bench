from pathlib import Path
import json,hashlib,shutil,tarfile,datetime,subprocess
r=Path(__file__).parent;w=Path('/tmp/ai-infra-pr56-hardening/tasks/vllm-runner-v2-selection');v=w/'validation'
results=json.loads((r/'results.json').read_text());assert len(results)==22 and all(x['reward']==x['expected'] and x['exit_code']==0 for x in results)
old_report_control=next(x for x in results if x['case']=='forged-observations');results=[json.loads((r/'report-control/runs/forged-observations/result.json').read_text()) if x['case']=='forged-observations' else x for x in results]
report_harbor=json.loads((r/'report-control/harbor-results.json').read_text());assert report_harbor[0]['reward']==0 and report_harbor[0]['exception'] is None
harbor=json.loads((r/'harbor-results.json').read_text());final=json.loads((r/'final-harbor/harbor-results.json').read_text());assert final[0]['reward']==1 and final[0]['exception'] is None
for item in results:
 log=((r/'report-control/runs' if item['case']=='forged-observations' else r/'runs')/item['case']/'verifier.log').read_text();item['passed']=sum(l.startswith('PASS:') for l in log.splitlines());item['failed_cases']=[l.split(':')[1].strip() for l in log.splitlines() if l.startswith('FAIL:')];item['completion_records']=[json.loads(l) for l in log.splitlines() if l.startswith('{"completed"')]
 if item['expected']==1:assert item['passed']==27 and all(not c['failures'] for c in item['completion_records'])
lookup={x['case']:x for x in results};ci=json.loads((v/'ci-cases.json').read_text());ci['status']='All 17 listed controls replayed against the 27-case 1.1.2 verifier; see pooling-evidence.json.'
for c in ci['cases']:
 x=lookup[c['name']];c['actual_reward']=x['reward'];c['execution_status']='1.1.2 Docker test.sh replay matched expected reward';c['patch_sha256']=hashlib.sha256((v/c['patch']).read_bytes()).hexdigest()
(v/'ci-cases.json').write_text(json.dumps(ci,indent=2)+'\n')
# Keep raw logs and harness provenance small; model caches and full repository exports remain local.
archive=v/'evidence/pooling-hardening-1.1.2.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for p in r.rglob('*'):
  rel=p.relative_to(r)
  if not p.is_file() or any(part in ('task','harbor-tasks','artifacts','__pycache__') for part in rel.parts):continue
  if p.suffix in ('.json','.log','.txt','.py') or p.name=='reward.txt':tar.add(p,arcname=str(rel))
 for n in (1,2,3):
  base=Path(f'/tmp/pr56-codex-medium-a688bee-3/final-artifacts/pr56-codex-a688bee-r{n}')
  for name in ('tracked.patch','manifest.json','status.z','base.txt','head.txt'):
   tar.add(base/name,arcname=f'candidate-sources/r{n}/{name}')
  tar.add(Path(f'/tmp/pr56-codex-medium-a688bee-3/review/r{n}-candidate-tests.py'),arcname=f'candidate-sources/r{n}/test_model_runner_selection.py')
source=Path('/root/ai-infra-bench-worksapce/ai-infra-bench');skill=source/'.agents/skills/ai-infra-bench-task-review'
evidence={'schema_version':'pooling_hardening.v1','recorded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'parent_commit':'a688bee189d2b7935d39535f6db6c635def5eb4b','task_version':'1.1.2','image_unchanged':'sha256:772e7f217078cee581097b23a4ea0458727f49a5a91afad996fa666a7c8acd2f','contract':'Existing forced-V2 incompatibility rejection; normalized LAST pooling is supported at Base, MEAN/CLS/disabled normalization are not.','boundary':'public ModelConfig -> VllmConfig -> Worker.init_device -> real runner or startup diagnostic','runs':results,'harbor_before_patch_format_normalization':harbor,'harbor_final':final,'updated_report_control_harbor':report_harbor,'superseded_report_control':{'result':old_report_control,'cause':'old stdin schema failed JSON decoding; not evidence of report-forgery rejection'},'patch_format_equivalence':json.loads((r/'patch-format-equivalence.json').read_text()),'raw_evidence':{'path':str(archive.relative_to(w)),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()},'replay_commands':['python3 -I /tmp/pr56-pooling-hardening/run.py','DOCKER_CONFIG=/tmp/pr56-codex-rollout-20260913/docker-config PYTHONPATH=/tmp/pr56-pooling-hardening/final-harbor /data/yinchen/harbor-claude-tap/.venv-host/bin/python /tmp/pr56-pooling-hardening/final-harbor/run-harbor.py'],'resource_plan':'Local controls run one container per GPU 0-5; Harbor on GPU 6/7. Each candidate requests 1 GPU, 4 CPUs, 16 GiB RAM, 2 GiB shm, network none.','scope':'No fresh model rollout. Original 21/21 rewards are unchanged. New full-suite replays are development evidence, not new independent model success-rate estimates.','publication':'Git push authorized; registry image publication remains pending.','skill':{'path':str(skill),'head':subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip(),'status':subprocess.check_output(['git','-C',str(source),'status','--short','--',str(skill)],text=True),'hashes':{str(p.relative_to(skill)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [skill/'SKILL.md',skill/'references/review-rubric.md']}}}
(v/'pooling-evidence.json').write_text(json.dumps(evidence,indent=2)+'\n')
rows='\n'.join(f"| {x['case']} | {x['expected']} | {x['reward']} | {x['passed']} | {x['seconds']} |" for x in results)
report='''# PR #56：pooling 兼容性补测与修复

题目保留，1.1.2 的 pooling 漏测已修复，完整控制矩阵和最终 Harbor Oracle 均通过预期验证。10/10 维度可评分，19/20；没有已知未修复的本轮行为阻塞，registry 发布仍待处理。以下结论仅覆盖代表性配置和已验证的评分边界，不声称穷尽所有 V2 特性组合。

父提交 a688bee189d2b7935d39535f6db6c635def5eb4b；工作区 `/tmp/ai-infra-pr56-hardening`，分支 `codex/runner-selection-permissions`。题面与环境不变，task 升为 1.1.2，继续使用 1.1.1 的同一镜像 digest。Git 身份为 `yaoxu <csxuyao@qq.com>`。此前环境报告保存在 history/pre-pooling-a688bee，原始 agent 分数保持不变。

| # | 维度 | 分数 / 状态 | 依据或边界 | 下一步 |
|---|---|---|---|---|
| 1 | 真实清楚 | 2 | 三段专业开发者 query 不变 | 保持简洁 |
| 2 | 独立于历史 PR | 2 | 根据 Base 行为纠正 Oracle | 不豁免参考解 |
| 3 | 环境可解 | 2 | 已验证镜像不变；三份真实 rollout 使用离线 pytest/hooks | 无需重建 |
| 4 | 双向对齐 | 2 | 27 项映射到既有选择和兼容性要求 | 保留代表性范围说明 |
| 5 | 真实执行路径 | 2 | 配置、CUDA/NCCL、Worker 和 runner 构造 | 不宣称权重加载或生成 |
| 6 | 正确替代实现 | 2 | 六个不同写法的正例及 Codex r2 通过 | 保留实现自由 |
| 7 | 错误解拒绝 | 2 | Base、旧 Oracle、r1/r3 和所有负例按预期失败 | 保留失败原因 |
| 8 | Oracle 独立验证 | 2 | 从源码推导的 pooling 挑战及最终 27 项验证 | 按同一契约验证 |
| 9 | 评分可信 | 2 | 伪造报告/认证、提前退出对照仍拒绝；Harbor 两类退出也验证 | 非任意 native 攻击沙箱 |
| 10 | 复现与交付 | 1 | 输入哈希、日志、最终 Harbor 和补丁等价性证据齐全 | registry 发布待完成 |

Gate 1、2 沿用未改变的契约和环境证据；Gate 3 本轮复查并验证。目标边界是配置和 override → 真实 ModelConfig/VllmConfig → Worker.init_device → 实际 runner 或启动诊断。只有无关的 ElasticEP orchestration 被替代，不加载权重，不执行完整 embedding 或文本生成。

原 verifier 对显式 V2 的 pooling 支持范围缺少检查：旧 Oracle 和 Codex r1/r3 会让 MEAN、CLS、关闭归一化的配置启动 V2。Base 的 V2 PoolingRunner 只返回归一化 LAST embeddings，题面已有“显式选择不支持配置应报错”的要求，因此新增六个场景没有扩大功能范围。加入三项负例，以及 normalized LAST→V2、自动 MEAN→V1、强制 V1 MEAN→V1 三项对照。测试只检查实际启动行为，不依赖私有 helper、异常类型或文案。

修复 Oracle 和六个正例的 pooling 判断，旧 Oracle 保留为 missing-pooling-check.patch。所有正例完整完成 27 项；负例可能在失败组后停止，未执行的项目不记为通过。详细失败条件和完成记录见 pooling-evidence.json。

| 本地重放 | 预期 | 实际 | PASS 项数 | 秒 |
|---|---|---|---|---|
'''+rows+'''

旧 forged-observations 反例仍读取过时的 stdin 格式，首次因 JSONDecodeError 失败，不能作为防伪造证据。本轮修正它，使其打印当前格式的完整成功报告并 os._exit(0)。重新经本地 test.sh 和正式 Harbor 验证，评分父进程均因零条认证完成记录拒绝，reward=0；不再依赖格式错误。该控制的更新不改变题面、评分器或 Oracle，已有 Oracle 验证仍对应同一执行内容。

本地矩阵使用冻结快照，最后仅清理了八个 patch 的空白上下文格式。对每个格式化后的 patch 都在干净 Base 上重新应用，并证明生成的完整 git diff SHA-256 与已运行版本相同；证明见 pooling-evidence.json。最终 Harbor Oracle 另以格式化后的实际 task 重跑成功，不用格式等价性替代正式入口验证。

最终 Harbor 使用单卡 GPU adapter，只指定设备及共享内存，不改评分逻辑。最终 Oracle reward=1、无 trial error、27 项全部完成；另一次 Oracle 与 SystemExit(0)、os._exit(0) 对照的正式 Harbor 结果也符合预期。输入 checksum 在最终证据里；更新证据和报告会改变 task 目录 checksum，不改变执行过的题面、测试或解法。

本轮没有新调用 Codex/DS，只重放已有最终解法。Codex r2 在当前完整 suite 通过，r1/r3 因 pooling 缺陷失败；这不重写它们历史 21/21 的分数，也不应当作为新的独立模型通过率。环境的所有依赖或平台组合不在此次穷举范围，镜像 registry 发布尚未完成。Git commit/push 状态以交付消息及远端 HEAD 为准。
'''
(v/'review-report.md').write_text(report)
old=json.loads((v/'history/pre-pooling-a688bee/e2e-evidence.json').read_text());old['recorded_at']=evidence['recorded_at'];old['status']='1.1.2 pooling hardening: full control matrix and final Harbor passed; registry pending';old['reviewed_revision']='a688bee189d2b7935d39535f6db6c635def5eb4b plus final files hashed below';old['identity'].update(parent_commit=evidence['parent_commit'], skill_path=evidence['skill']['path'], skill_head=evidence['skill']['head'], skill_dirty=bool(evidence['skill']['status']), skill_hashes=evidence['skill']['hashes']);old['identity']['change_scope']='Six pooling behavior cases and reference/control guards; instruction and image unchanged';old['validation']={'pooling_hardening':evidence,'prior_environment_evidence':'validation/history/pre-pooling-a688bee/e2e-evidence.json'}
paths=[w/'instruction.md',w/'task.toml',*list((w/'tests').rglob('*')),*list((w/'solution').rglob('*')),*list((w/'environment').rglob('*')),v/'ci-cases.json',*list(v.glob('*.patch')),v/'pooling-evidence.json']
old['artifacts']={'files':{str(p.relative_to(w)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths if p.is_file()}};(v/'e2e-evidence.json').write_text(json.dumps(old,indent=2)+'\n')
print('Evidence and report finalized')
