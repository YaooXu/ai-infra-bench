from pathlib import Path
import json,subprocess,hashlib,time,shutil
r=Path(__file__).parent;c='pr54-codex-feedback-verifier';image='sha256:d11035d323cd8044e4a1aea97d0c3f7a03ae7865cadc84893bd045686da65eed';source=Path('/tmp/ai-infra-pr54-hardening/tasks/vllm-dp-multi-port-supervisor/tests')
assert json.loads((r/'agent-result.json').read_text())['exit_code']==0
snapshot=r/'verifier-snapshot';shutil.copytree(source,snapshot)
def digest(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
before={str(p.relative_to(r)):digest(p) for p in snapshot.rglob('*') if p.is_file()};before['workspace.tar']=digest(r/'workspace.tar');(r/'verification-inputs-before.json').write_text(json.dumps({'image':image,'sha256':before},indent=2)+'\n')
subprocess.run(['docker','run','-d','--name',c,'--network','none','--cpus','4','--memory','16g','--user','root','-v',str(snapshot)+':/tests:ro',image,'sleep','infinity'],check=True,stdout=subprocess.DEVNULL)
t=time.monotonic()
try:
 subprocess.run(['docker','cp',str(r/'workspace.tar'),c+':/tmp/workspace.tar'],check=True)
 subprocess.run(['docker','exec',c,'tar','-C','/workspace/repo','-xf','/tmp/workspace.tar'],check=True)
 with (r/'verifier.log').open('w') as log:p=subprocess.run(['docker','exec',c,'timeout','900','bash','/tests/test.sh'],stdout=log,stderr=subprocess.STDOUT)
 reward=subprocess.check_output(['docker','exec',c,'cat','/logs/verifier/reward.txt'],text=True).strip()
 resources=json.loads(subprocess.check_output(['docker','exec',c,'python3','-c','import psutil,os,json; print(json.dumps({"processes":[(p.pid,p.name(),p.status()) for p in psutil.process_iter() if p.pid not in (1,os.getpid())],"listeners":[c.laddr.port for c in psutil.net_connections("tcp") if c.status=="LISTEN"]}))'],text=True))
 result={'reward':reward,'shell_exit_code':p.returncode,'elapsed_s':round(time.monotonic()-t,2),'post_verifier_resources':resources,'scope':'Full task 1.2.0 scoring after one feedback continuation; not a new Harbor rollout or a replacement of the original score.'}
 (r/'verification-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
finally:subprocess.run(['docker','rm','-f',c],stdout=subprocess.DEVNULL)
after={p:digest(r/p) for p in before};(r/'verification-inputs-after.json').write_text(json.dumps({'unchanged':before==after,'sha256':after},indent=2)+'\n');assert before==after
