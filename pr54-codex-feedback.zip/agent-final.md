Fixed cleanup using Linux child subreaper support. The supervisor now adopts, terminates, and reaps detached descendants before exiting, releasing their listeners.

All 22 tests passed, including both requested failure timings, detached-worker SIGTERM/SIGINT shutdown, and existing behavior:

```bash
.venv/bin/python -m unittest tests.entrypoints.test_dp_supervisor -v
```

Direct repository checks passed; full pre-commit remains unavailable.
