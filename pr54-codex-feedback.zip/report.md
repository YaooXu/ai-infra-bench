# 原 Codex 会话的一次反馈修复

结论：补充一次行为反馈后，Codex 修复了此前发现的后代清理遗漏；独立 task 1.2.0 完整评分 reward=1。这是有反馈的续接修复结果，不改写原始一次作答成绩，也不是一次从头生成答案的新 rollout。

原 session `01a096fe-894e-7de1-85c8-6ee0c189181d` 通过 Codex 0.153.4 的 `exec resume` 续接，模型保持 gpt-6-astra / high。原 session 文件在新文件中作为完全一致的前缀保留，见 [session-continuity.json](session-continuity.json)。原 container 已被 Harbor 删除，因此是在同一 image 上恢复原 workspace 和会话；缺失的 venv Python symlink 按原 pyvenv.cfg 恢复，不能声称保留了原运行中的进程状态。

## 给它的提示

完整原文见 [feedback.txt](feedback.txt)。提示指出：rank 创建独立 POSIX session 的后代后，在首次 ready 前退出或 ready 后被杀掉，会留下后代和 TCP listener；要求遵守原题清理任何后代的约定，补两种时序的回归，并保持正常 SIGTERM/SIGINT 及既有行为。没有提供 Oracle、正式 verifier、新增测试实现或指定清理算法。

首次续接因未按原 Harbor 方式写入 Codex auth 文件而收到 401，没有任何模型修复动作；修正认证初始化后，从原 session 再续接同一条提示。这条成功续接用时 392.03 秒。认证失败记录单独保存在 `/data/pr54-codex-feedback-auth-failed-20260913`，不计为做题失败。

## 实际改动和验证

相对原答案只改了三个文件：supervisor、自测、部署文档，见 [feedback-only.patch](feedback-only.patch)。它采用 Linux child subreaper，在启动 rank 前启用孤儿接管，关闭时清理并回收后代；同时保留原先存在的子进程，退出后恢复原 subreaper 设置。新增自测覆盖跨 session 后代、两种 rank 退出时序和相关状态恢复。它自己的最终 22 项 unittest 通过；早期红测及测试 socket 超时修正也留在原始续接日志中。完整 pre-commit 仍不可用，没有把它报告为已通过。

随后把最终 workspace 的 tar 快照恢复到独立、无网络、4 CPU/16 GiB Docker 容器，运行未经针对答案修改的完整 `/tests/test.sh`。task 1.2.0 的测试和最终 workspace 在运行前记录 SHA256，运行后未变化。验证耗时 349.64 秒，结果见 [verification-result.json](verification-result.json) 与 [verifier.log](verifier.log)。

| 答案 / 测试版本 | 结果 |
|---|---|
| 原始答案，原 task 1.1.0 | 历史 reward 1，后续确认是假阳性 |
| 原始答案，task 1.2.0 | reward 0，真实 detached descendant 与 listener 泄漏 |
| 一次反馈后的答案，task 1.2.0 | reward 1 |

新版六个顶层检查组及三个后代清理子场景全部完成。独立观察确认启动期和 ready 后 rank 死亡时后代与端口已清理；正常 SIGINT、原健康探测、设备映射、非法参数和 ordinary serve 回归均通过。评分结束后资源检查为 `{"processes": [], "listeners": []}`。这是通过当前行为契约测试的证据，不是穷尽所有部署配置的正确性证明。

## 交付与限制

[agent.jsonl](agent.jsonl) 为本次续接 native 事件，[agent-final.md](agent-final.md) 为模型最终答复，[sessions](sessions) 保存含原会话的完整续接记录。`workspace.tar` 保留最终源码、native 文件、symlink 与模式位，另有 [workspace-manifest.json](workspace-manifest.json)；Git 历史仍由固定 Base 标识，缓存不归档。未丢失原 regular capture 的任何文件，新增捕获补齐了镜像 native 与已恢复的链接。repo 外完整状态不在此次快照保证内。

原 task、Oracle、原 rollout、原 ZIP 和原分数未修改；修复答案保存在本目录，没有替换 task 的参考解、没有 commit/push。本轮只完成一次反馈续接和一次独立完整 Docker 评分，没有新 Harbor rollout。已检查日志和文本交付物未包含已知 relay credential。

`feedback-evidence.zip` 是续接轨迹、增量 patch、三个修改文件和验证证据包；体积较大的完整 `workspace.tar` 单独保留在本目录。要从增量包复原全部代码，需要原答案包。续接使用方式也可参见 [官方 non-interactive 文档](https://learn.chatgpt.com/docs/non-interactive-mode)，本次实际连续性另由本地 session 前缀校验确认。
