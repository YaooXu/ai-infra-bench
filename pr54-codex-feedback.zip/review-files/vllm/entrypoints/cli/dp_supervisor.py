# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM project
"""Node-local supervision of external-LB API servers.

Each rank runs in a fresh interpreter and POSIX session. Device visibility is
set before importing the serving stack. The supervisor acts as a Linux child
subreaper so workers cannot escape cleanup by creating their own session.
"""

import argparse
import asyncio
import contextlib
import copy
import ctypes
import logging
import math
import os
import pickle
import signal
import subprocess
import sys
import tempfile
from collections.abc import Iterator

import aiohttp
import psutil
from aiohttp import web

logger = logging.getLogger(__name__)


@contextlib.contextmanager
def child_subreaper() -> Iterator[None]:
    """Adopt orphaned descendants, including ones we have never observed.

    Process-tree polling alone cannot find a worker that detaches and loses
    its parent between polls. Enable adoption before launching any ranks and
    keep it enabled until their descendants have been terminated and reaped.
    """
    if sys.platform != "linux":
        raise RuntimeError("The DP supervisor requires Linux child subreaper support")
    libc = ctypes.CDLL(None, use_errno=True)
    previous = ctypes.c_int()
    # prctl(PR_GET_CHILD_SUBREAPER, &previous) / PR_SET_CHILD_SUBREAPER.
    if libc.prctl(37, ctypes.byref(previous), 0, 0, 0) != 0:
        raise OSError(ctypes.get_errno(), "PR_GET_CHILD_SUBREAPER failed")
    if libc.prctl(36, 1, 0, 0, 0) != 0:
        raise OSError(ctypes.get_errno(), "PR_SET_CHILD_SUBREAPER failed")
    try:
        yield
    finally:
        if libc.prctl(36, previous.value, 0, 0, 0) != 0:
            raise OSError(ctypes.get_errno(), "Restoring child subreaper state failed")


def add_cli_args(parser: argparse.ArgumentParser) -> None:
    group = parser.add_argument_group("Data parallel supervisor")
    group.add_argument(
        "--data-parallel-multi-port-external-lb",
        action="store_true",
        help="Supervise one API server per local DP rank on consecutive ports "
        "starting at --port. Use --data-parallel-start-rank for the first rank.",
    )
    group.add_argument(
        "--data-parallel-supervisor-port",
        type=int,
        default=None,
        help="Required in multi-port external LB mode. Serves aggregate "
        "/health, /ready and /readyz on --host over HTTP.",
    )
    group.add_argument(
        "--dp-supervisor-probe-interval-s",
        type=float,
        default=1.0,
        help="Seconds between rounds of rank health probes (default: 1).",
    )
    group.add_argument(
        "--dp-supervisor-probe-timeout-s",
        type=float,
        default=1.0,
        help="Timeout in seconds for each rank health probe (default: 1).",
    )
    group.add_argument(
        "--dp-supervisor-probe-failure-threshold",
        type=int,
        default=3,
        help="Consecutive failures of a rank after initial group readiness "
        "before stopping the group (default: 3).",
    )


def validate_args(args: argparse.Namespace) -> None:
    for name in (
        "headless",
        "data_parallel_hybrid_lb",
        "data_parallel_external_lb",
        "grpc",
        "uds",
        "enable_elastic_ep",
    ):
        if getattr(args, name, False):
            raise ValueError(
                f"--{name.replace('_', '-')} conflicts with "
                "--data-parallel-multi-port-external-lb"
            )
    if args.data_parallel_rank is not None:
        raise ValueError("Use --data-parallel-start-rank, not --data-parallel-rank")
    if args.api_server_count not in (None, 1):
        raise ValueError("Multi-port external LB requires one API server per rank")
    if getattr(args, "nnodes", 1) != 1:
        raise ValueError("Multi-port external LB requires node-local TP/PP (nnodes=1)")
    if getattr(args, "data_parallel_backend", "mp") != "mp" or getattr(
        args, "distributed_executor_backend", None
    ) not in (None, "mp", "uni"):
        raise ValueError("Multi-port external LB requires local multiprocessing")
    size = args.data_parallel_size
    local = args.data_parallel_size_local
    start = args.data_parallel_start_rank or 0
    if size <= 1:
        raise ValueError("--data-parallel-size must be greater than 1 for external LB")
    if local is None:
        local = size
    if local <= 0 or start < 0 or start + local > size:
        raise ValueError("Local DP rank range must be nonempty and within the DP size")
    for name in (
        "tensor_parallel_size",
        "pipeline_parallel_size",
        "prefill_context_parallel_size",
    ):
        if getattr(args, name, 1) <= 0:
            raise ValueError(f"--{name.replace('_', '-')} must be positive")
    for name in (
        "dp_supervisor_probe_interval_s",
        "dp_supervisor_probe_timeout_s",
        "dp_supervisor_probe_failure_threshold",
    ):
        value = getattr(args, name)
        if not math.isfinite(value) or value <= 0:
            raise ValueError(f"--{name.replace('_', '-')} must be finite and positive")
    if not 1 <= args.port <= args.port + local - 1 <= 65535:
        raise ValueError("Child ports must be in the range 1..65535")
    port = args.data_parallel_supervisor_port
    if port is None or not 1 <= port <= 65535:
        raise ValueError(
            "--data-parallel-supervisor-port must be in the range 1..65535"
        )
    if args.port <= port < args.port + local:
        raise ValueError("Supervisor port overlaps a child port")


def rank_launches(
    args: argparse.Namespace, device_env_var: str
) -> list[tuple[argparse.Namespace, dict[str, str]]]:
    """Resolve every launch before starting any processes.

    Slice the original visibility list directly, including GPU UUIDs and MIG
    identifiers. Global DP rank offsets must not affect local device indices.
    """
    validate_args(args)
    local = args.data_parallel_size_local or args.data_parallel_size
    width = (
        args.tensor_parallel_size
        * args.pipeline_parallel_size
        * getattr(args, "prefill_context_parallel_size", 1)
    )
    visible = os.environ.get(device_env_var)
    devices = (
        [device.strip() for device in visible.split(",")]
        if visible is not None
        else [str(i) for i in range(local * width)]
    )
    if len(devices) < local * width or any(not device for device in devices):
        raise ValueError(
            f"{device_env_var} has too few devices for local DP * TP * PP * PCP"
        )
    launches = []
    for rank in range(local):
        child = copy.deepcopy(args)
        child.data_parallel_multi_port_external_lb = False
        child.data_parallel_supervisor_port = None
        child.data_parallel_external_lb = True
        child.data_parallel_hybrid_lb = False
        child.data_parallel_rank = (args.data_parallel_start_rank or 0) + rank
        child.data_parallel_start_rank = None
        child.data_parallel_size_local = 1
        child.api_server_count = 1
        child.port = args.port + rank
        # CLI dispatch callbacks are unnecessary in the fresh interpreter.
        child.__dict__.pop("dispatch_function", None)
        env = os.environ.copy()
        env[device_env_var] = ",".join(devices[rank * width : (rank + 1) * width])
        # ROCm normalizes these aliases on platform initialization and rejects
        # mismatched values when the child imports the platform again.
        if device_env_var == "CUDA_VISIBLE_DEVICES" and "HIP_VISIBLE_DEVICES" in env:
            env["HIP_VISIBLE_DEVICES"] = env[device_env_var]
        launches.append((child, env))
    return launches


def launch_rank(args: argparse.Namespace, env: dict[str, str]) -> subprocess.Popen:
    # Serialize the parsed namespace, preserving config-file options and custom
    # argparse values without reconstructing or reparsing the command line.
    # stdin is a private, parent-created file, never input from a network client.
    with tempfile.TemporaryFile() as config:
        pickle.dump(args, config)
        config.seek(0)
        return subprocess.Popen(
            [sys.executable, "-m", "vllm.entrypoints.cli.dp_supervisor"],
            stdin=config,
            env=env,
            start_new_session=True,
        )


class DPSupervisor:
    def __init__(self, args: argparse.Namespace):
        self.args = args
        self.processes: list[subprocess.Popen] = []
        self.healthy = [False] * (
            args.data_parallel_size_local or args.data_parallel_size
        )
        self.failures = [0] * len(self.healthy)
        self.ever_ready = False
        self.stopping = asyncio.Event()
        self.failure: str | None = None
        self._existing_children: set[psutil.Process] | None = None

    @property
    def ready(self) -> bool:
        return (
            not self.stopping.is_set()
            and len(self.processes) == len(self.healthy)
            and all(self.healthy)
            and all(proc.poll() is None for proc in self.processes)
        )

    async def health(self, request: web.Request) -> web.Response:
        ready = self.ready
        return web.Response(
            status=200 if ready else 503,
            text="ready\n" if ready else "not ready\n",
        )

    def record_probe(self, rank: int, healthy: bool) -> None:
        self.healthy[rank] = healthy
        if healthy:
            self.failures[rank] = 0
        elif self.ever_ready:
            self.failures[rank] += 1
            if self.failures[rank] >= self.args.dp_supervisor_probe_failure_threshold:
                self.failure = (
                    f"Local DP rank {rank} reached the health failure threshold"
                )
                self.stopping.set()
        if not self.ever_ready and all(self.healthy):
            self.ever_ready = True
            logger.info("All local DP ranks are healthy; supervisor is ready")

    async def probe(self, session: aiohttp.ClientSession, rank: int) -> None:
        host = self.args.host or "127.0.0.1"
        if host in ("0.0.0.0", "::"):
            host = "::1" if host == "::" else "127.0.0.1"
        if ":" in host and not host.startswith("["):
            host = f"[{host}]"
        scheme = "https" if getattr(self.args, "ssl_certfile", None) else "http"
        url = f"{scheme}://{host}:{self.args.port + rank}/health"
        healthy = False
        try:
            # Only inspect status. Redirects are failures, and environment HTTP
            # proxies must not intercept probes of local workers. TLS identity
            # is not verified for this local liveness check.
            async with session.get(url, allow_redirects=False, ssl=False) as response:
                healthy = response.status == 200
        except (aiohttp.ClientError, TimeoutError):
            pass
        self.record_probe(rank, healthy)

    async def probe_loop(self) -> None:
        timeout = aiohttp.ClientTimeout(total=self.args.dp_supervisor_probe_timeout_s)
        async with aiohttp.ClientSession(timeout=timeout, trust_env=False) as session:
            while not self.stopping.is_set():
                await asyncio.gather(
                    *(self.probe(session, rank) for rank in range(len(self.healthy)))
                )
                await asyncio.sleep(self.args.dp_supervisor_probe_interval_s)

    async def monitor_processes(self) -> None:
        while not self.stopping.is_set():
            for rank, proc in enumerate(self.processes):
                if (code := proc.poll()) is not None:
                    self.failure = f"Local DP rank {rank} exited with code {code}"
                    self.stopping.set()
                    return
            await asyncio.sleep(0.1)

    def owned_children(self) -> list[psutil.Process]:
        if self._existing_children is None:
            return []
        # This serve process owns children started during run(), including
        # adopted orphans. Preserve processes that predate the supervisor.
        return [
            child
            for child in psutil.Process().children()
            if child not in self._existing_children
        ]

    async def shutdown(self, grace_s: float = 5.0) -> None:
        self.stopping.set()
        logger.info("Stopping local DP ranks and their descendants")
        # Always signal the saved process group, even if its leader has exited.
        # Waiting only for Popen.poll() would miss orphaned engine workers.
        def signal_groups(sig: signal.Signals) -> None:
            for proc in self.processes:
                with contextlib.suppress(ProcessLookupError):
                    os.killpg(proc.pid, sig)

        signal_groups(signal.SIGTERM)
        term_sent: set[psutil.Process] = set()
        rank_pids = {proc.pid for proc in self.processes}
        deadline = asyncio.get_running_loop().time() + grace_s
        while asyncio.get_running_loop().time() < deadline:
            for child in self.owned_children():
                with contextlib.suppress(psutil.NoSuchProcess):
                    for descendant in [child, *child.children(recursive=True)]:
                        if descendant not in term_sent:
                            with contextlib.suppress(psutil.NoSuchProcess):
                                # psutil checks process identity before signaling,
                                # protecting against PID reuse across sweeps.
                                descendant.terminate()
                            term_sent.add(descendant)
                if child.pid not in rank_pids and child.is_running():
                    with contextlib.suppress(ChildProcessError):
                        os.waitpid(child.pid, os.WNOHANG)
            alive = False
            for proc in self.processes:
                proc.poll()  # Reap exited leaders before checking the group.
                try:
                    os.killpg(proc.pid, 0)
                    alive = True
                except ProcessLookupError:
                    pass
            if not alive and not self.owned_children():
                break
            await asyncio.sleep(0.05)
        signal_groups(signal.SIGKILL)
        for proc in self.processes:
            proc.wait()
        # Killing a child can orphan another generation, possibly in a separate
        # session. Drain adopted children until none remain; waiting only for
        # rank leaders or taking one process-tree snapshot leaks these workers.
        while children := self.owned_children():
            for child in children:
                with contextlib.suppress(psutil.NoSuchProcess):
                    child.kill()
                    with contextlib.suppress(ChildProcessError):
                        os.waitpid(child.pid, os.WNOHANG)
            await asyncio.sleep(0.01)

    async def run(
        self, launches: list[tuple[argparse.Namespace, dict[str, str]]]
    ) -> None:
        self._existing_children = set(psutil.Process().children(recursive=True))
        with child_subreaper():
            await self._run(launches)

    async def _run(
        self, launches: list[tuple[argparse.Namespace, dict[str, str]]]
    ) -> None:
        loop = asyncio.get_running_loop()
        old_handlers = {
            sig: signal.getsignal(sig) for sig in (signal.SIGTERM, signal.SIGINT)
        }
        runner = web.AppRunner(self.create_app(), access_log=None)
        tasks: list[asyncio.Task] = []
        try:
            for sig in old_handlers:
                loop.add_signal_handler(sig, self.stopping.set)
            await runner.setup()
            await web.TCPSite(
                runner,
                self.args.host or "0.0.0.0",
                self.args.data_parallel_supervisor_port,
            ).start()
            logger.info(
                "DP supervisor listening on %s:%d",
                self.args.host or "0.0.0.0",
                self.args.data_parallel_supervisor_port,
            )
            for child, env in launches:
                if self.stopping.is_set():
                    break
                self.processes.append(launch_rank(child, env))
                logger.info(
                    "Started DP rank %d on port %d (pid %d)",
                    child.data_parallel_rank,
                    child.port,
                    self.processes[-1].pid,
                )
                await asyncio.sleep(0)  # Deliver shutdown signals during startup.
            tasks = [
                asyncio.create_task(self.probe_loop()),
                asyncio.create_task(self.monitor_processes()),
                asyncio.create_task(self.stopping.wait()),
            ]
            done, _ = await asyncio.wait(tasks, return_when=asyncio.FIRST_COMPLETED)
            for task in done:
                task.result()
            if self.failure:
                raise RuntimeError(self.failure)
        finally:
            self.stopping.set()
            for task in tasks:
                task.cancel()
            await asyncio.gather(*tasks, return_exceptions=True)
            try:
                await self.shutdown()
            finally:
                try:
                    await runner.cleanup()
                finally:
                    for sig, handler in old_handlers.items():
                        loop.remove_signal_handler(sig)
                        signal.signal(sig, handler)

    def create_app(self) -> web.Application:
        app = web.Application()
        for path in ("/health", "/ready", "/readyz"):
            app.router.add_get(path, self.health)
        return app


def run_dp_supervisor(args: argparse.Namespace) -> None:
    from vllm.platforms import current_platform

    validate_args(args)
    launches = rank_launches(args, current_platform.device_control_env_var)
    asyncio.run(DPSupervisor(args).run(launches))


if __name__ == "__main__":
    args = pickle.load(sys.stdin.buffer)
    from vllm.entrypoints.cli.serve import ServeSubcommand

    ServeSubcommand.cmd(args)
