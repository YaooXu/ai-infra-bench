# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM project
"""CPU-only supervisor tests, also runnable with python -m unittest."""

import argparse
import asyncio
import ctypes
import json
import os
import signal
import socket
import subprocess
import sys
import tempfile
import time
import unittest
from pathlib import Path
from unittest.mock import Mock, patch

import aiohttp
import psutil
from aiohttp import web

from vllm.entrypoints.cli import dp_supervisor as dp


def make_args(**overrides):
    args = argparse.Namespace(
        data_parallel_multi_port_external_lb=True,
        data_parallel_supervisor_port=9000,
        data_parallel_size=4,
        data_parallel_size_local=2,
        data_parallel_start_rank=2,
        data_parallel_rank=None,
        data_parallel_external_lb=False,
        data_parallel_hybrid_lb=False,
        tensor_parallel_size=1,
        pipeline_parallel_size=1,
        api_server_count=None,
        headless=False,
        host="127.0.0.1",
        port=8000,
        dp_supervisor_probe_interval_s=0.05,
        dp_supervisor_probe_timeout_s=0.1,
        dp_supervisor_probe_failure_threshold=3,
    )
    vars(args).update(overrides)
    return args


class TestLaunchConfiguration(unittest.TestCase):
    def test_subreaper_state_restored_on_error(self):
        def state():
            value = ctypes.c_int()
            self.assertEqual(
                ctypes.CDLL(None).prctl(37, ctypes.byref(value), 0, 0, 0), 0
            )
            return value.value

        original = state()
        with self.assertRaisesRegex(RuntimeError, "startup failed"):
            with dp.child_subreaper():
                self.assertEqual(state(), 1)
                raise RuntimeError("startup failed")
        self.assertEqual(state(), original)

    def test_parser_defaults(self):
        parser = argparse.ArgumentParser()
        dp.add_cli_args(parser)
        args = parser.parse_args([])
        self.assertFalse(args.data_parallel_multi_port_external_lb)
        self.assertIsNone(args.data_parallel_supervisor_port)
        self.assertEqual(args.dp_supervisor_probe_interval_s, 1)
        self.assertEqual(args.dp_supervisor_probe_timeout_s, 1)
        self.assertEqual(args.dp_supervisor_probe_failure_threshold, 3)

    def test_invalid_configuration(self):
        cases = [
            {"headless": True},
            {"data_parallel_hybrid_lb": True},
            {"data_parallel_external_lb": True},
            {"data_parallel_rank": 0},
            {"grpc": True},
            {"uds": "/tmp/server.sock"},
            {"api_server_count": 0},
            {"api_server_count": 2},
            {"data_parallel_size": 1},
            {"data_parallel_size_local": 0},
            {"data_parallel_size_local": -1},
            {"data_parallel_start_rank": -1},
            {"data_parallel_start_rank": 3},
            {"tensor_parallel_size": 0},
            {"pipeline_parallel_size": -1},
            {"prefill_context_parallel_size": 0},
            {"data_parallel_supervisor_port": None},
            {"data_parallel_supervisor_port": 8000},
            {"data_parallel_supervisor_port": 8001},
            {"data_parallel_supervisor_port": 65536},
            {"port": 0},
            {"port": 65535},
            {"nnodes": 2},
            {"data_parallel_backend": "ray"},
        ]
        for name in (
            "dp_supervisor_probe_interval_s",
            "dp_supervisor_probe_timeout_s",
            "dp_supervisor_probe_failure_threshold",
        ):
            cases.extend({name: value} for value in (0, -1, float("inf"), float("nan")))
        for overrides in cases:
            with self.subTest(overrides=overrides), self.assertRaises(ValueError):
                dp.validate_args(make_args(**overrides))

    def test_device_slices_and_child_options(self):
        args = make_args(tensor_parallel_size=2, pipeline_parallel_size=2)
        args.extra_option = {"nested": ["config-file value"]}
        devices = ["GPU-a", "MIG-b", "7", "3", "GPU-c", "MIG-d", "1", "5"]
        with patch.dict(os.environ, {"CUDA_VISIBLE_DEVICES": ",".join(devices)}):
            launches = dp.rank_launches(args, "CUDA_VISIBLE_DEVICES")
            self.assertEqual(os.environ["CUDA_VISIBLE_DEVICES"], ",".join(devices))
        for local_rank, (child, env) in enumerate(launches):
            self.assertEqual(child.port, 8000 + local_rank)
            self.assertEqual(child.data_parallel_rank, 2 + local_rank)
            self.assertEqual(child.data_parallel_size, 4)
            self.assertEqual(child.data_parallel_size_local, 1)
            self.assertIsNone(child.data_parallel_start_rank)
            self.assertTrue(child.data_parallel_external_lb)
            self.assertFalse(child.data_parallel_multi_port_external_lb)
            self.assertEqual(child.api_server_count, 1)
            self.assertEqual(child.extra_option, args.extra_option)
            self.assertEqual(
                env["CUDA_VISIBLE_DEVICES"],
                ",".join(devices[local_rank * 4 : (local_rank + 1) * 4]),
            )
        self.assertTrue(args.data_parallel_multi_port_external_lb)
        self.assertIsNone(args.data_parallel_rank)

    def test_unrestricted_devices_and_defaults(self):
        with patch.dict(os.environ, {}, clear=True):
            launches = dp.rank_launches(
                make_args(
                    data_parallel_start_rank=None,
                    data_parallel_size_local=None,
                    tensor_parallel_size=2,
                ),
                "ZE_AFFINITY_MASK",
            )
        self.assertEqual(len(launches), 4)
        self.assertEqual(launches[3][1]["ZE_AFFINITY_MASK"], "6,7")

    def test_insufficient_devices(self):
        for visible in ("", "0", "0,,1"):
            with (
                self.subTest(visible=visible),
                patch.dict(os.environ, {"CUDA_VISIBLE_DEVICES": visible}),
                self.assertRaises(ValueError),
            ):
                dp.rank_launches(make_args(), "CUDA_VISIBLE_DEVICES")

    def test_prefill_context_parallel_devices(self):
        with patch.dict(os.environ, {}, clear=True):
            launches = dp.rank_launches(
                make_args(
                    tensor_parallel_size=2,
                    pipeline_parallel_size=2,
                    prefill_context_parallel_size=2,
                ),
                "CUDA_VISIBLE_DEVICES",
            )
        self.assertEqual(
            launches[1][1]["CUDA_VISIBLE_DEVICES"], "8,9,10,11,12,13,14,15"
        )

    def test_rocm_visibility_aliases(self):
        with patch.dict(
            os.environ,
            {"CUDA_VISIBLE_DEVICES": "3,1", "HIP_VISIBLE_DEVICES": "3,1"},
        ):
            launches = dp.rank_launches(make_args(), "CUDA_VISIBLE_DEVICES")
        self.assertEqual(launches[0][1]["HIP_VISIBLE_DEVICES"], "3")
        self.assertEqual(launches[1][1]["HIP_VISIBLE_DEVICES"], "1")

    def test_full_serve_parser(self):
        from vllm.entrypoints.openai.cli_args import (
            make_arg_parser,
            validate_parsed_serve_args,
        )
        from vllm.utils.argparse_utils import FlexibleArgumentParser

        with patch("vllm.platforms.current_platform.device_type", "cpu"):
            parser = make_arg_parser(FlexibleArgumentParser())
        args = parser.parse_args(
            [
                "test-model",
                "--data-parallel-multi-port-external-lb",
                "--data-parallel-size",
                "4",
                "--data-parallel-size-local",
                "2",
                "--data-parallel-start-rank",
                "2",
                "--data-parallel-supervisor-port",
                "9000",
                "--dp-supervisor-probe-interval-s",
                "2.5",
                "--dp-supervisor-probe-timeout-s",
                "0.2",
                "--dp-supervisor-probe-failure-threshold",
                "4",
            ]
        )
        validate_parsed_serve_args(args)
        self.assertEqual(args.dp_supervisor_probe_interval_s, 2.5)
        self.assertEqual(args.dp_supervisor_probe_timeout_s, 0.2)
        self.assertEqual(args.dp_supervisor_probe_failure_threshold, 4)

    def test_serve_dispatch(self):
        from vllm.entrypoints.cli.serve import ServeSubcommand

        args = make_args()
        with patch.object(dp, "run_dp_supervisor") as run:
            ServeSubcommand.cmd(args)
            run.assert_called_once_with(args)
        args.data_parallel_multi_port_external_lb = False
        args.data_parallel_size = 1
        args.data_parallel_start_rank = None
        with (
            patch("vllm.entrypoints.cli.serve.envs.VLLM_RUST_FRONTEND_PATH", None),
            patch("vllm.entrypoints.cli.serve.run_server", Mock(return_value="server")),
            patch("vllm.entrypoints.cli.serve.uvloop.run") as run,
            patch.object(dp, "run_dp_supervisor") as supervisor,
        ):
            ServeSubcommand.cmd(args)
            run.assert_called_once_with("server")
            supervisor.assert_not_called()


class TestHealth(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.supervisor = dp.DPSupervisor(make_args())
        self.supervisor.processes = [Mock(), Mock()]
        for proc in self.supervisor.processes:
            proc.poll.return_value = None
        self.runners = []
        self.session = aiohttp.ClientSession()

    async def asyncTearDown(self):
        await self.session.close()
        for runner in self.runners:
            await runner.cleanup()

    async def serve(self, app):
        runner = web.AppRunner(app)
        self.runners.append(runner)
        await runner.setup()
        site = web.TCPSite(runner, "127.0.0.1", 0)
        await site.start()
        return runner.addresses[0][1]

    async def assert_routes(self, port, status):
        for route in ("health", "ready", "readyz"):
            async with self.session.get(f"http://127.0.0.1:{port}/{route}") as response:
                self.assertEqual(response.status, status)

    async def test_readiness_and_failure_counts(self):
        sup = self.supervisor
        port = await self.serve(sup.create_app())
        await self.assert_routes(port, 503)
        for _ in range(10):
            sup.record_probe(0, True)
            sup.record_probe(1, False)
        self.assertEqual(sup.failures, [0, 0])
        self.assertFalse(sup.stopping.is_set())
        await self.assert_routes(port, 503)
        sup.record_probe(1, True)
        await self.assert_routes(port, 200)
        sup.record_probe(0, False)
        await self.assert_routes(port, 503)
        sup.record_probe(1, False)
        self.assertEqual(sup.failures, [1, 1])
        sup.record_probe(0, True)
        self.assertEqual(sup.failures, [0, 1])
        sup.record_probe(1, True)
        await self.assert_routes(port, 200)
        for _ in range(3):
            sup.record_probe(0, False)
        self.assertTrue(sup.stopping.is_set())
        await self.assert_routes(port, 503)

    async def test_exited_rank_is_never_ready(self):
        sup = self.supervisor
        sup.healthy = [True, True]
        sup.processes[0].poll.return_value = 0
        await self.assert_routes(await self.serve(sup.create_app()), 503)
        await sup.monitor_processes()
        self.assertTrue(sup.stopping.is_set())
        self.assertIn("exited with code 0", sup.failure)

    async def test_http_failures_and_timeout(self):
        status = 200
        delay = 0

        async def handler(request):
            await asyncio.sleep(delay)
            return web.Response(status=status, headers={"Location": "/health"})

        app = web.Application()
        app.router.add_get("/health", handler)
        port = await self.serve(app)
        self.supervisor.args.port = port
        self.supervisor.record_probe(1, True)
        timeout = aiohttp.ClientTimeout(total=0.03)
        async with aiohttp.ClientSession(timeout=timeout) as session:
            await self.supervisor.probe(session, 0)
            self.assertTrue(self.supervisor.ready)
            for status in (503, 302):
                await self.supervisor.probe(session, 0)
                self.assertFalse(self.supervisor.ready)
            self.assertEqual(self.supervisor.failures[0], 2)
            status = 200
            await self.supervisor.probe(session, 0)
            self.assertEqual(self.supervisor.failures[0], 0)
            delay = 0.1
            await self.supervisor.probe(session, 0)
            self.assertEqual(self.supervisor.failures[0], 1)
            await self.runners[0].cleanup()
            await self.supervisor.probe(session, 0)
            self.assertEqual(self.supervisor.failures[0], 2)

    async def test_partial_launch_is_cleaned_up(self):
        sup = dp.DPSupervisor(make_args(data_parallel_supervisor_port=0))
        process = Mock(pid=123)
        process.poll.return_value = None
        with (
            patch.object(
                dp, "launch_rank", side_effect=[process, OSError("spawn failed")]
            ),
            patch.object(dp.os, "killpg", side_effect=ProcessLookupError) as killpg,
            self.assertRaisesRegex(OSError, "spawn failed"),
        ):
            await sup.run([(make_args(data_parallel_rank=0), {})] * 2)
        killpg.assert_any_call(123, signal.SIGTERM)
        killpg.assert_any_call(123, signal.SIGKILL)
        process.wait.assert_called_once()

    async def test_supervisor_bind_failure_starts_no_children(self):
        with socket.socket() as held:
            held.bind(("127.0.0.1", 0))
            held.listen()
            args = make_args(data_parallel_supervisor_port=held.getsockname()[1])
            sup = dp.DPSupervisor(args)
            with patch.object(dp, "launch_rank") as launch:
                with self.assertRaises(OSError):
                    await sup.run([(args, {})])
                launch.assert_not_called()
            self.assertTrue(sup.stopping.is_set())

    async def test_failed_startup_preserves_existing_child(self):
        child = subprocess.Popen(
            [sys.executable, "-c", "import time; time.sleep(60)"]
        )
        try:
            sup = dp.DPSupervisor(make_args(data_parallel_supervisor_port=0))
            with patch.object(dp, "launch_rank", side_effect=OSError("spawn failed")):
                with self.assertRaisesRegex(OSError, "spawn failed"):
                    await sup.run([(make_args(), {})])
            self.assertIsNone(child.poll())
        finally:
            child.terminate()
            child.wait()


# Subprocess fixtures use only real TCP servers and process groups. The worker
# ignores SIGTERM and keeps a listening socket after its rank leader exits.
_RANK = """
import http.server, os, pathlib, subprocess, sys, time
root, rank, port = pathlib.Path(sys.argv[1]), sys.argv[2], int(sys.argv[3])
(root / ('rank-' + rank)).write_text(str(os.getpid()))
worker = subprocess.Popen(
    [sys.executable, '-c', sys.argv[4], str(root), rank],
    start_new_session=sys.argv[5] == 'True',
)
if rank == '0' and sys.argv[6] == 'True':
    while not (root / ('worker-' + rank)).exists(): time.sleep(0.01)
    os._exit(0)
class Handler(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        path = root / ('status-' + rank)
        status = int(path.read_text()) if path.exists() else 503
        self.send_response(status)
        self.end_headers()
    def log_message(self, *args): pass
http.server.HTTPServer(('127.0.0.1', port), Handler).serve_forever()
"""
_WORKER = """
import os, pathlib, signal, socket, sys, time
signal.signal(signal.SIGTERM, signal.SIG_IGN)
sock = socket.socket()
sock.bind(('127.0.0.1', 0))
sock.listen()
(pathlib.Path(sys.argv[1]) / ('worker-' + sys.argv[2])).write_text(
    str(os.getpid()) + ',' + str(sock.getsockname()[1]))
while True: time.sleep(1)
"""


def run_fixture(root):
    root = Path(root)
    args = make_args(**json.loads((root / "config").read_text()))
    index = 0

    def launch(child, env):
        nonlocal index
        rank = index
        index += 1
        return subprocess.Popen(
            [
                sys.executable,
                "-c",
                _RANK,
                str(root),
                str(rank),
                str(child.port),
                _WORKER,
                str(getattr(args, "detached_workers", False)),
                str(getattr(args, "exit_during_startup", False)),
            ],
            start_new_session=True,
        )

    class FastShutdown(dp.DPSupervisor):
        async def shutdown(self, grace_s=0.2):
            await super().shutdown(grace_s)

    with patch.object(dp, "launch_rank", launch):
        launches = dp.rank_launches(args, "TEST_VISIBLE_DEVICES")
        asyncio.run(FastShutdown(args).run(launches))


class TestProcessLifecycle(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.proc = None
        self.session = aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=0.2))
        # Reserve a consecutive pair and a distinct supervisor port until launch.
        self.sockets = []
        while True:
            first = socket.socket()
            first.bind(("127.0.0.1", 0))
            self.port = first.getsockname()[1]
            second = socket.socket()
            try:
                second.bind(("127.0.0.1", self.port + 1))
            except OSError:
                first.close()
                second.close()
                continue
            self.sockets.extend([first, second])
            break
        supervisor = socket.socket()
        supervisor.bind(("127.0.0.1", 0))
        self.supervisor_port = supervisor.getsockname()[1]
        self.sockets.append(supervisor)

    async def asyncTearDown(self):
        if self.proc is not None:
            if self.proc.poll() is None:
                self.proc.terminate()
            try:
                await asyncio.to_thread(self.proc.wait, timeout=10)
            finally:
                if self.proc.poll() is None:
                    self.proc.kill()
                    self.proc.wait()
        for path in self.root.glob("rank-*"):
            try:
                os.killpg(int(path.read_text()), signal.SIGKILL)
            except ProcessLookupError:
                pass
        # Also clean up detached workers when a regression assertion fails.
        for path in self.root.glob("worker-*"):
            try:
                os.kill(int(path.read_text().split(",")[0]), signal.SIGKILL)
            except ProcessLookupError:
                pass
        for sock in self.sockets:
            sock.close()
        await self.session.close()
        self.temp.cleanup()

    async def wait_for(self, predicate, timeout=10):
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            if predicate():
                return
            await asyncio.sleep(0.02)
        self.fail("Timed out waiting for subprocess state")

    async def start(self, **overrides):
        config = {
            "port": self.port,
            "data_parallel_supervisor_port": self.supervisor_port,
        }
        config.update(overrides)
        (self.root / "config").write_text(json.dumps(config))
        for sock in self.sockets:
            sock.close()
        self.proc = subprocess.Popen(
            [
                sys.executable,
                "-c",
                "from tests.entrypoints.test_dp_supervisor import run_fixture; "
                "import sys; run_fixture(sys.argv[1])",
                str(self.root),
            ],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        await self.wait_for(lambda: len(list(self.root.glob("worker-*"))) == 2)

    async def wait_status(self, expected):
        deadline = time.monotonic() + 10
        while time.monotonic() < deadline:
            try:
                async with self.session.get(
                    f"http://127.0.0.1:{self.supervisor_port}/readyz"
                ) as response:
                    if response.status == expected:
                        return
            except (aiohttp.ClientError, TimeoutError):
                pass
            await asyncio.sleep(0.02)
        self.fail(f"Supervisor did not return {expected}")

    def make_ready(self):
        for rank in range(2):
            (self.root / f"status-{rank}").write_text("200")

    async def assert_stopped(self, failed):
        await self.wait_for(lambda: self.proc.poll() is not None)
        self.assertEqual(self.proc.returncode != 0, failed)
        ports = [self.port, self.port + 1, self.supervisor_port]
        ports.extend(
            int(path.read_text().split(",")[1])
            for path in self.root.glob("worker-*")
        )
        # SIGKILL delivery can lag behind wait() on the rank leader.
        def sockets_released():
            for port in ports:
                with socket.socket() as sock:
                    sock.settimeout(0.1)
                    if sock.connect_ex(("127.0.0.1", port)) == 0:
                        return False
            return True
        await self.wait_for(sockets_released)
        for port in ports:
            with socket.socket() as sock:
                sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                sock.bind(("127.0.0.1", port))

    async def test_exit_during_startup_cleans_orphan(self):
        await self.start()
        await self.wait_status(503)
        await asyncio.sleep(0.3)  # More startup failures than the threshold.
        self.assertIsNone(self.proc.poll())
        os.kill(int((self.root / "rank-0").read_text()), signal.SIGKILL)
        await self.assert_stopped(failed=True)

    async def test_health_failure_stops_group(self):
        await self.start()
        self.make_ready()
        await self.wait_status(200)
        (self.root / "status-1").write_text("503")
        await self.wait_status(503)
        await self.assert_stopped(failed=True)

    def assert_detached_workers_reaped(self):
        for path in self.root.glob("worker-*"):
            pid = int(path.read_text().split(",")[0])
            self.assertFalse(psutil.pid_exists(pid), f"Worker {pid} was not reaped")

    async def test_detached_worker_rank_exits_before_readiness(self):
        # Rank 0 exits itself immediately after spawning its detached worker,
        # without waiting for a supervisor probe or process-tree scan.
        await self.start(detached_workers=True, exit_during_startup=True)
        await self.assert_stopped(failed=True)
        self.assert_detached_workers_reaped()

    async def test_detached_worker_rank_killed_after_readiness(self):
        await self.start(detached_workers=True)
        self.make_ready()
        await self.wait_status(200)
        rank_pid = int((self.root / "rank-0").read_text())
        worker_pid = int((self.root / "worker-0").read_text().split(",")[0])
        self.assertEqual(os.getsid(worker_pid), worker_pid)
        self.assertNotEqual(os.getsid(worker_pid), os.getsid(rank_pid))
        os.kill(rank_pid, signal.SIGKILL)
        await self.assert_stopped(failed=True)
        self.assert_detached_workers_reaped()

    async def test_sigterm(self):
        await self.start(detached_workers=True)
        self.make_ready()
        await self.wait_status(200)
        self.proc.send_signal(signal.SIGTERM)
        await self.assert_stopped(failed=False)
        self.assert_detached_workers_reaped()

    async def test_sigint_during_startup(self):
        await self.start(detached_workers=True)
        await self.wait_status(503)
        self.proc.send_signal(signal.SIGINT)
        await self.assert_stopped(failed=False)
        self.assert_detached_workers_reaped()


if __name__ == "__main__":
    unittest.main()
