from pathlib import Path
import subprocess,json,os,time,hashlib,tarfile,shutil
r=Path(__file__).parent;original=Path('/data/pr54-codex-20260913');c='pr54-codex-feedback';image='sha256:d11035d323cd8044e4a1aea97d0c3f7a03ae7865cadc84893bd045686da65eed'
sessions=next((original/'jobs/codex-pr54-authenticated').glob('*/agent/sessions'));session=next(sessions.rglob('*.jsonl'));sid='01a096fe-894e-7de1-85c8-6ee0c189181d'
config=json.loads((original/'harbor-config-authenticated.json').read_text());env=os.environ.copy();env['OPENAI_API_KEY']=Path('/data/yinchen/astra-three-rerun-20260911/private/relay-key').read_text().strip()
cmd=['docker','run','-d','--name',c,'--network','none','--cpus','4','--memory','16g','--user','root']
for m in config['environment']['mounts']:cmd+=['-v',m['source']+':'+m['target']+':ro']
cmd += [image,'sleep','infinity'];subprocess.run(cmd,check=True,stdout=subprocess.DEVNULL)
subprocess.run(['docker','cp',str(original/'candidate-workspace')+'/.',c+':/workspace/repo/'],check=True)
subprocess.run(['docker','exec',c,'mkdir','-p','/tmp/codex-home'],check=True)
subprocess.run(['docker','cp',str(sessions),c+':/tmp/codex-home/sessions'],check=True)
subprocess.run(['docker','exec',c,'ln','-sf','/usr/bin/python3','/workspace/repo/.venv/bin/python'],check=True)
for name in ['python3','python3.12']:subprocess.run(['docker','exec',c,'ln','-sf','python','/workspace/repo/.venv/bin/'+name],check=True)
subprocess.run(['docker','exec',c,'chown','-R','agent:agent','/workspace/repo','/tmp/codex-home'],check=True)
subprocess.run(['docker','exec','-u','agent','-e','OPENAI_API_KEY',c,'python3','-c',"import os,json,pathlib; p=pathlib.Path('/tmp/codex-home/auth.json'); p.write_text(json.dumps({'OPENAI_API_KEY':os.environ['OPENAI_API_KEY']})); p.chmod(0o600)"],env=env,check=True)
initial={'source_session_id':sid,'source_session_sha256':hashlib.sha256(session.read_bytes()).hexdigest(),'source_trial':'task-snapshot__7ZFV5ah','model':'gpt-6-astra','reasoning_effort':'high','codex_version':'0.153.4','image':image,'feedback_sha256':hashlib.sha256((r/'feedback.txt').read_bytes()).hexdigest(),'restoration':'Original regular workspace over original image; restored venv interpreter symlinks from pyvenv.cfg; original session JSONL copied unchanged. No task tests or solution supplied.','mode':'One feedback continuation, not a fresh rollout or original-score replacement.'}
(r/'manifest-before.json').write_text(json.dumps(initial,indent=2)+'\n')
args=['docker','exec','-i','-u','agent','-w','/workspace/repo','-e','OPENAI_API_KEY','-e','CODEX_HOME=/tmp/codex-home',c,'codex','exec','resume','--dangerously-bypass-approvals-and-sandbox','--skip-git-repo-check','--json','--enable','unified_exec','-m','gpt-6-astra']
def walk(prefix,value):
 if isinstance(value,dict):
  for k,v in value.items():yield from walk(prefix+'.'+k if prefix else k,v)
 else:yield prefix,value
for k,v in walk('',config['agents'][0]['kwargs']['config']):args+=['-c',k+'='+json.dumps(v)]
args += [sid,'-'];t=time.monotonic()
with (r/'agent.jsonl').open('w') as log:
 p=subprocess.run(args,input=(r/'feedback.txt').read_bytes(),env=env,stdout=log,stderr=subprocess.STDOUT)
result={'exit_code':p.returncode,'elapsed_s':round(time.monotonic()-t,2)};(r/'agent-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
# Preserve links/modes and untracked files before grading. Git history is pinned
# separately; caches are omitted, but native binaries and venv links are kept.
with (r/'workspace.tar').open('wb') as f:subprocess.run(['docker','exec',c,'tar','-C','/workspace/repo','--exclude=./.git','--exclude=__pycache__','--exclude=.pytest_cache','--exclude=.ruff_cache','-cf','-','.'],stdout=f,check=True)
(r/'final-tracked.patch').write_bytes(subprocess.check_output(['docker','exec',c,'git','-C','/workspace/repo','-c','safe.directory=/workspace/repo','diff','--binary','HEAD']))
(r/'final-status.txt').write_bytes(subprocess.check_output(['docker','exec',c,'git','-C','/workspace/repo','-c','safe.directory=/workspace/repo','status','--short','--untracked-files=all']))
subprocess.run(['docker','cp',c+':/tmp/codex-home/sessions',str(r/'sessions')],check=True)
print('CAPTURE_COMPLETE',flush=True)
